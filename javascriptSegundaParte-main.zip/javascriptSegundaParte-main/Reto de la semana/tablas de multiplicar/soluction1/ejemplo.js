let tablas = () => {
    // Tabla 1
    for (let ciclo = 1; ciclo <= 5; ciclo++) {
        //++ autoincrementable    ciclo++   ciclo=ciclo +1
        let tabla = 1;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[0].appendChild(texth1);
    }
    // Tabla 2
    for (let ciclo = 3; ciclo <= 10; ciclo++) {
        let tabla = 2;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[1].appendChild(texth1);

    }
    
    // Tabla 3
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 3;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[2].appendChild(texth1);
    }
    // Tabla 4
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 4;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[3].appendChild(texth1);
    }
    // Tabla 5
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 5;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[4].appendChild(texth1);
    }
    // Tabla 6
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 6;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[5].appendChild(texth1);
    }
    // Tabla 7
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 7;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[6].appendChild(texth1);
    }
    // Tabla 8
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 8;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[7].appendChild(texth1);
    }
    // Tabla 9
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 9;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[8].appendChild(texth1);
    }
    // Tabla 10
    for (let ciclo = 1; ciclo <= 10; ciclo++) {
        let tabla = 10;
        let texth1 = document.createElement("tr");
        let resultado = ciclo * tabla;
        texth1.innerHTML = `<td>${tabla}*${ciclo}</td><td>=${resultado}</td>`;
        document.getElementsByTagName("tbody")[9].appendChild(texth1);
    }
    
}
