const item = document.querySelectorAll("option");
console.log(item);
