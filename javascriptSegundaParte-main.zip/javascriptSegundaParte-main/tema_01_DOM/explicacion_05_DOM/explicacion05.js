// Create element:
// etiquetas
let para = document.createElement('div');
para.innerText = 'Esto es un ejemplo 1.';
para.className='claseNuevas'
//Se agrega al final de la etiqueta
// body
document.body.appendChild(para);

let paraTwo = document.createElement('div');
paraTwo.innerText = 'Esto es un ejemplo 1.';
paraTwo.className='claseNuevas'
//Se agrega al final de la etiqueta
// body
document.body.appendChild(paraTwo);
