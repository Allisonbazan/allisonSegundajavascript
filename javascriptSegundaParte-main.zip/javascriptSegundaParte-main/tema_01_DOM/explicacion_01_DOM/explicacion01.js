let myElement = document.getElementById('cube');
// style apariencia
myElement.style.background = 'red';
myElement.style.color = '#FFFF';
// html contenido
myElement.innerHTML = 'Aqui ando';