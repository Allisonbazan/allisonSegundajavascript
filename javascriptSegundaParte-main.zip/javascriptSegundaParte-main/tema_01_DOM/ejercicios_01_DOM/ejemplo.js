const agregar1= () => {
    let texth1 = document.createElement("h1");
    texth1.innerText = "Acción del botón 1"; 
    document.getElementById("bot1").appendChild(texth1);
 }
  const agregar2= () => {
     let texth2 = document.createElement("p");
     texth2.innerText = "Acción del botón 2";
     document.getElementById("bot2").appendChild(texth2);
  }
 
  const agregar3= () => {
     alert('text');
  }