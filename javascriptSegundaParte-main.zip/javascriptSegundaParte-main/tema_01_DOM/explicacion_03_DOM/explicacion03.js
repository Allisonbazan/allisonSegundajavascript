// Busco por etiquetas
const items = document.getElementsByTagName('option');
items[1].style.background = 'red';