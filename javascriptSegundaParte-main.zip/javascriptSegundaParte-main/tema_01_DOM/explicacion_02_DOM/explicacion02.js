const mycube = document.getElementsByClassName("cube");
console.log(mycube);
console.log(mycube.length);
mycube[mycube.length - 1].style.background = 'blue';